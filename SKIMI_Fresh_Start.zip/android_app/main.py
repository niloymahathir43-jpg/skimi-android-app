from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup
from kivy.uix.label import Label

KV = """
<RootScreen>:
    BoxLayout:
        orientation: "vertical"
        canvas.before:
            Color:
                rgba: (0.035, 0.055, 0.12, 1)
            Rectangle:
                pos: self.pos
                size: self.size
        BoxLayout:
            size_hint_y: None
            height: "64dp"
            padding: "16dp", 0
            Label:
                text: "[b]SKIMI[/b]"
                markup: True
                font_size: "25sp"
                color: (0.35, 1, 0.65, 1)
            Label:
                text: "Your smart space"
                color: (0.8, 0.86, 1, 1)
        ScreenManager:
            id: pages
            Screen:
                name: "home"
                BoxLayout:
                    orientation: "vertical"
                    padding: "20dp"
                    spacing: "12dp"
                    Label:
                        text: "Welcome to SKIMI"
                        font_size: "25sp"
                    Label:
                        text: "Chat, learn, create and keep your ideas in one place."
                    Button:
                        text: "Open AI Assistant"
                        on_release: pages.current = "ai"
                    Button:
                        text: "Open Chat"
                        on_release: pages.current = "chat"
            Screen:
                name: "chat"
                BoxLayout:
                    orientation: "vertical"
                    padding: "18dp"
                    Label:
                        text: "Chat"
                        font_size: "24sp"
                    Label:
                        text: "Starter screen. Online chat needs a backend."
                    TextInput:
                        hint_text: "Write a message..."
                        size_hint_y: None
                        height: "52dp"
                        multiline: False
                    Button:
                        text: "Send (demo)"
                        size_hint_y: None
                        height: "48dp"
                        on_release: app.info("Demo only", "Online chat is not connected yet.")
            Screen:
                name: "ai"
                BoxLayout:
                    orientation: "vertical"
                    padding: "18dp"
                    Label:
                        text: "SKIMI AI"
                        font_size: "24sp"
                    Label:
                        text: "AI assistant starter screen"
                    TextInput:
                        hint_text: "Ask SKIMI something..."
                        size_hint_y: None
                        height: "54dp"
                        multiline: False
                    Button:
                        text: "Ask (demo)"
                        size_hint_y: None
                        height: "48dp"
                        on_release: app.info("Not connected", "AI needs a secure API connection.")
            Screen:
                name: "notes"
                BoxLayout:
                    orientation: "vertical"
                    padding: "18dp"
                    Label:
                        text: "My Notes"
                        font_size: "24sp"
                    TextInput:
                        hint_text: "Write your notes here..."
            Screen:
                name: "settings"
                BoxLayout:
                    orientation: "vertical"
                    padding: "18dp"
                    Label:
                        text: "Settings"
                        font_size: "24sp"
                    Label:
                        text: "Account, language and privacy settings will be added."
        BoxLayout:
            size_hint_y: None
            height: "60dp"
            Button:
                text: "Home"
                on_release: pages.current = "home"
            Button:
                text: "Chat"
                on_release: pages.current = "chat"
            Button:
                text: "AI"
                on_release: pages.current = "ai"
            Button:
                text: "Notes"
                on_release: pages.current = "notes"
            Button:
                text: "Settings"
                on_release: pages.current = "settings"
"""

class RootScreen(Screen):
    pass

class SkimiApp(App):
    def build(self):
        Builder.load_string(KV)
        return RootScreen()

    def info(self, title, message):
        Popup(title=title, content=Label(text=message),
              size_hint=(0.85, 0.35)).open()

if __name__ == "__main__":
    SkimiApp().run()
